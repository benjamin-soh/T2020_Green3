﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using Newtonsoft.Json;
using RestSharp;
using static TechTrekG3.JsonHelper;

namespace TechTrekG3
{
    public partial class Login : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            //marytan accoundId:74
            //limzeyang accoundId:10
            //prasannaghali accountId: 32
            int custId =callAPI_getCustomerID("prasannaghali"); //OK 
            //Label1.Text = "customer ID: "+custId.ToString();
            
            string custDetails = callAPI_getCustomerDetail(custId); //OK
            //Label1.Text = custDetails;

            string accountDepositList = callAPI_getDepositList(custId); //ok
            //Label1.Text = accountDepositList;

            //Label1.Text = custDetails + "\n" + accountDepositList;

            //int accId = callAPI_getAccountId(custId);
            //Label1.Text = accId.ToString();


            // int 74 needa change it to accountId
            string getDepositAccountBalance = callAPI_getDepositAccountBalance(32); //ok
            //Label1.Text = getDepositAccountBalance;

            string getListofCreditAmount = callAPI_getListofCreditAmount(custId); //ok
            //Label1.Text = getListofCreditAmount;

            
            string etCreditAccountOutstandingBalance = callAPI_getCreditAccountOutstandingBalance(32); //ok
            //Label1.Text = etCreditAccountOutstandingBalance;

            string transacationDetails = callAPI_getTransactionDetail(74, "01-01-2018", "02-01-2019");
            Label1.Text=transacationDetails;

            string MarketingMesage = callAPI_getMarketingMessage();
            //Label1.Text = MarketingMesage;

            string MarketingDetails = callAPI_getMarketingMessageDetails(1);
            //Label1.Text = MarketingDetails;

            string PersonalMessage = callAPI_getPersonalMessages(custId);
            //Label1.Text = PersonalMessage;



            /*Label1.Text = custDetails + "\n\n" +
                           accountDepositList + "\n\n" +
                           getDepositAccountBalance + "\n\n" +
                          getListofCreditAmount + "\n\n" +
                           etCreditAccountOutstandingBalance + "\n\n" +
                           transacationDetails + "\n\n" +
                           PersonalMessage;*/





        }


        public int callAPI_getCustomerID(string customerName)
        {
            int custId = 0;
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/customers/" +customerName);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);
           
            if (response.StatusCode.ToString() == "OK")
            {
                Customer jsonOjb = JsonConvert.DeserializeObject<Customer>(response.Content);
                string userName = jsonOjb.userName.ToString();
                int customerId = jsonOjb.customerId;
                custId = customerId;
            }

            return custId;
            
        }
   

        public string callAPI_getCustomerDetail(int custId)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/customers/" + custId+ "/details");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {
                //Customer jsonOjb = JsonConvert.DeserializeObject<Customer>(response.Content);
                //string firstName = jsonOjb.firstName.ToString();
                //string lastName = jsonOjb.lastName.ToString();
                //string lastLogIn = jsonOjb.lastLogIn.ToString();
                //string dateOfBirth = jsonOjb.dateOfBirth.ToString();

                jsonDetails= response.Content.ToString();


            }

            return response.Content.ToString();


        }


        public string callAPI_getDepositList(int custId)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/deposit/"+ custId);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {
                //Account jsonOjb = JsonConvert.DeserializeObject<Account>(response.Content);
                //int accountId = jsonOjb.accountId;
                //string type = jsonOjb.type.ToString();
                //string displayName = jsonOjb.displayName.ToString();
                //string accountNumber = jsonOjb.accountNumber.ToString();

                jsonDetails = response.Content.ToString();


            }

            return response.Content.ToString();


        }



        //http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/deposit/:accountId/balance?month=1&year=2018

        public string callAPI_getDepositAccountBalance(int accId)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/deposit/" + accId+"/balance");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            /*request.AddJsonBody(
              new
              {
                  month = 1,
                  year = 12

              });*/
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {
               
                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }

        //http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/credit/:customerId
        public string callAPI_getListofCreditAmount(int custId)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/credit/"+ custId);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }


        /*  public int callAPI_getAccountId(int custId) 
          {
              int accId = 0;
              string identifier = "Group22";
              string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
              var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/deposit/" + custId);
              var request = new RestRequest(Method.GET);
              request.AddHeader("content-type", "application/json");
              request.AddHeader("identity", identifier);
              request.AddHeader("token", token);
              IRestResponse response = client.Execute(request);

              if (response.StatusCode.ToString() == "OK")
              {       
                  accId = accountId;

              }
              return accId;

          }*/



        public string callAPI_getTransactionDetail(int accId,string startDate,string endDate)
        {
            string transactionDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/transactions/" + accId+"?from=" +startDate+ "&to="+endDate );
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);
            if (response.StatusCode.ToString() == "OK")
            {
                transactionDetails = response.Content.ToString();

            }


            return transactionDetails;
        }

     
        public string callAPI_getCreditAccountOutstandingBalance(int accId)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/accounts/credit/" + accId + "/balance");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }

           public string callAPI_getMarketingMessage()
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/marketing");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }

        //http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/marketing/id

        public string callAPI_getMarketingMessageDetails(int id)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/marketing/"+id);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }

        //http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/message/:customerId

        public string callAPI_getPersonalMessages(int custid)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/message/" + custid);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                jsonDetails = response.Content.ToString();
            }

            return response.Content.ToString();


        }

    }
}