﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static TechTrekG3.JsonHelper;

namespace TechTrekG3
{
    public partial class MarketingDetails : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            int MarketingIndex = (int)Session["MarketingIndex"];

            callAPI_getMarketingMessageDetails(MarketingIndex);

        }

        public void callAPI_getMarketingMessageDetails(int id)
        {
            string jsonDetails = "";
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/marketing/" + id);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);

            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {

                //jsonDetails = response.Content.ToString();

                Marketing jsonOjb = JsonConvert.DeserializeObject<Marketing>(response.Content);
                
                string dateCreated = jsonOjb.dateCreated.ToString();
                string subject = jsonOjb.subject.ToString();
                string body = jsonOjb.body.ToString();
                string summary = jsonOjb.summary.ToString();
                lblBody.Text = body;
                lblDateCreated.Text = dateCreated;
                lblSubject.Text = subject;
                lblSummary.Text = summary;
            }

           


        }
    }
}