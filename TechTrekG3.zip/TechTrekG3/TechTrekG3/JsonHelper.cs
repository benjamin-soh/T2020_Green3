﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace TechTrekG3
{
    public class JsonHelper
    {
        public class Customer
        {
            public string userName { get; set; }
            public int customerId { get; set; }

            public string firstName { get; set; }

            public string lastName { get; set; }

            public string lastLogIn { get; set; }

            public string dateOfBirth { get; set; }

            public string gender { get; set; }

        }

        public class Account
        {
            public List<AccountInner> index{ get; set; }
    }
        public class AccountInner
        {
            public int accountId { get; set; }
            public string type { get; set; }

            public string displayName { get; set; }

            public string accountNumber { get; set; }
            
        }

        public class Marketing
        {
            public string summary { get; set; }
            public string dateCreated { get; set; }
            public string subject { get; set; }
            public string body { get; set; }

        }


    }
}