﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Text.RegularExpressions;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static TechTrekG3.JsonHelper;

namespace TechTrekG3
{
    public partial class NextPage : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            string username = (String)Session["UserName"];
            
            int custId = callAPI_getCustomerID(username);
            callAPI_getCustomerDetail(custId);

        }

        public int callAPI_getCustomerID(string customerName)
        {
            int custId = 0;
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/customers/" + customerName);
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {
                Customer jsonOjb = JsonConvert.DeserializeObject<Customer>(response.Content);
                string userName = jsonOjb.userName.ToString();
                int customerId = jsonOjb.customerId;
                custId = customerId;
            }

            return custId;

        }

        public void callAPI_getCustomerDetail(int custId)
        {
           
            string identifier = "Group22";
            string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
            var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/customers/" + custId + "/details");
            var request = new RestRequest(Method.GET);
            request.AddHeader("content-type", "application/json");
            request.AddHeader("identity", identifier);
            request.AddHeader("token", token);
            IRestResponse response = client.Execute(request);

            if (response.StatusCode.ToString() == "OK")
            {
                Customer jsonOjb = JsonConvert.DeserializeObject<Customer>(response.Content);
                string firstName = jsonOjb.firstName.ToString();
                string lastName = jsonOjb.lastName.ToString();
                string lastLogIn = jsonOjb.lastLogIn.ToString();
                string gender = jsonOjb.gender.ToString();
                string dateOfBirth = jsonOjb.dateOfBirth.ToString();

                //jsonDetails = response.Content.ToString();
                txtFName.Text = firstName;
                txtLName.Text = lastName;
                txtLastLogin.Text = lastLogIn;
                txtDOB.Text = dateOfBirth;
                txtGender.Text = gender;


            }
            else
            {
                lblMsg.Text="Fail to retrieve User Details";
            }
            
        }

    

        
    }
}