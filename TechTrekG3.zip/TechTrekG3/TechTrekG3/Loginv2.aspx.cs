﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

namespace TechTrekG3
{
    public partial class Loginv2 : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {

        }

        protected void btnLogin_Click(object sender, EventArgs e)
        {
            string username = txtUsername.Text;
            string password = txtPassword.Text;
            
            if (checkValidUsername(username)&& checkValidPassword(password))
            {
               
                //lblMsg.Text = "Login Success";
                Session["UserName"] = username;
                Session["AccountId"] = getUserAccountId(username);
                Response.Redirect("NextPage.aspx");
            }
            else
                lblMsg.Text = "Invalid User";

        }

        private bool checkValidUsername(string username)
        {
            if (username == "marytan" || username == "limzeyang" || username == "prasannaghali")
                return true;
            else return false;
        }

        private bool checkValidPassword(string password)
        {
            if (password == "123456")
                return true;
            else return false;
        }

        private int getUserAccountId(string username)
        {
            if (username == "marytan")
                return 74;
            else if (username == "limzeyang")
                return 10;
            else if (username == "prasannaghali")
                return 32;
            else
                return 0;

        }
       
    }
}