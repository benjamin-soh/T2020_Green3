﻿using Newtonsoft.Json;
using RestSharp;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using static TechTrekG3.JsonHelper;

namespace TechTrekG3
{
    public partial class Home : System.Web.UI.Page
    {
        protected void Page_Load(object sender, EventArgs e)
        {
            //callAPI_getMarketingMessage(); 
        }

        protected void Button1_Click(object sender, EventArgs e)
        {
            Session["MarketingIndex"] = 1;
            Response.Redirect("MarketingDetails.aspx");
        }

        protected void Button2_Click(object sender, EventArgs e)
        {
            Session["MarketingIndex"] = 2;
            Response.Redirect("MarketingDetails.aspx");
        }

        protected void Button3_Click(object sender, EventArgs e)
        {
            Session["MarketingIndex"] = 3;
            Response.Redirect("MarketingDetails.aspx");
        }

        /*   public void callAPI_getMarketingMessage()
           {

               string identifier = "Group22";
               string token = "0b868a08-2d5e-4c1b-a6eb-b5b771cfb354";
               var client = new RestClient("http://techtrek-api-gateway.ap-southeast-1.elasticbeanstalk.com/marketing");
               var request = new RestRequest(Method.GET);
               request.AddHeader("content-type", "application/json");
               request.AddHeader("identity", identifier);
               request.AddHeader("token", token);

               IRestResponse response = client.Execute(request);

               if (response.StatusCode.ToString() == "OK")
               {

                   List <Marketing> jsonOjb = JsonConvert.DeserializeObject<List<Marketing>>(response.Content);
                   string type = jsonOjb.ToString();
                   Label1.Text = type;

               }

               //return response.Content.ToString();


           }
           */
    }
}